package com.miniProject.Employees.Management;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeesManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
